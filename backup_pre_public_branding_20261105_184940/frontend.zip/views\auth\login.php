<div class="auth-split-wrapper">
    <section class="auth-split-left" aria-labelledby="login-heading">
        <div class="auth-brand">
            <div class="brand-mark" aria-hidden="true"><i class="fa fa-shield-halved"></i></div>
            <div><strong>Padayon Hinaplanon</strong><span>Barangay Hinaplanon · Iligan City</span></div>
        </div>
        <div class="auth-intro">
            <h1 id="login-heading">Welcome back.</h1>
            <p>Sign in to view your community updates and the services available to your account.</p>
        </div>
        <?php foreach (($flashes ?? []) as $type => $messages): ?>
            <?php foreach ($messages as $msg): ?>
                <div class="alert alert-<?= htmlspecialchars($type) ?>" role="alert"><i class="fa fa-circle-info" aria-hidden="true"></i><div><?= htmlspecialchars($msg) ?></div></div>
            <?php endforeach; ?>
        <?php endforeach; ?>
        <form action="index.php?route=login" method="POST">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
            <div class="form-group">
                <label for="identifier" class="form-label">Barangay ID number or email *</label>
                <div style="position: relative;">
                    <input type="text" id="identifier" name="identifier" class="form-control" placeholder="Your Barangay ID or email address" required autofocus autocomplete="username" aria-describedby="identifier-help" style="padding-left: 42px;">
                    <i class="fa fa-id-card input-icon" aria-hidden="true"></i>
                </div>
                <small id="identifier-help" class="field-hint">Use your registered Barangay ID, email, or username.</small>
            </div>
            <div class="form-group">
                <div class="page-actions" style="justify-content: space-between; margin-bottom: 8px;">
                    <label for="password" class="form-label" style="margin-bottom: 0;">Password *</label>
                    <a href="index.php?route=forgot-password" style="font-size: .85rem;">Forgot password?</a>
                </div>
                <div style="position: relative;">
                    <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required autocomplete="current-password" style="padding-left: 42px; padding-right: 48px;">
                    <i class="fa fa-lock input-icon" aria-hidden="true"></i>
                    <button type="button" id="togglePassword" class="password-toggle" aria-label="Show password" aria-pressed="false" title="Show password"><i class="fa fa-eye" aria-hidden="true"></i></button>
                </div>
            </div>
            <button type="submit" class="btn btn-primary auth-submit"><i class="fa fa-right-to-bracket" aria-hidden="true"></i> Sign in</button>
        </form>
        <div class="auth-footer">New to the community portal?<br><a href="index.php?route=register"><strong>Register with your Barangay ID</strong></a></div>
        <details class="auth-demo">
            <summary><i class="fa fa-key" aria-hidden="true"></i> Thesis demonstration accounts</summary>
            <p class="field-hint">Select a role to fill the demonstration credentials. Then choose Sign in.</p>
            <div class="page-actions">
                <button type="button" class="btn btn-outline btn-sm" data-demo-identifier="icdrrmo@iligan.gov.ph" data-demo-pass="icdrrmo123">ICDRRMO</button>
                <button type="button" class="btn btn-outline btn-sm" data-demo-identifier="brgyhead@hinaplanon.gov.ph" data-demo-pass="brgyhead123">Barangay Head</button>
                <button type="button" class="btn btn-outline btn-sm" data-demo-identifier="responder1@hinaplanon.gov.ph" data-demo-pass="responder123">Responder</button>
                <button type="button" class="btn btn-outline btn-sm" data-demo-identifier="RES-2026-001" data-demo-pass="resident123">Resident</button>
            </div>
        </details>
    </section>
    <section class="auth-split-right" aria-label="Public community hazard map">
        <div class="map-floating-panel">
            <div class="page-kicker">Know your community</div>
            <h2 style="font-size: 1.25rem; color: var(--primary-dark); margin: 6px 0 8px;">Preparedness starts with awareness.</h2>
            <p style="font-size: .9rem; color: var(--text-muted);">Explore the public Hinaplanon Hazard Map. Select a marker to view the recorded information for that location.</p>
        </div>
        <div id="loginPublicMap" aria-label="Interactive map of Barangay Hinaplanon"></div>
        <div class="map-floating-panel">
            <div class="page-actions" style="font-size: .8125rem;">
                <span><i class="fa fa-circle" style="color: var(--hazard-pink);" aria-hidden="true"></i> High risk</span>
                <span><i class="fa fa-circle" style="color: var(--hazard-orange);" aria-hidden="true"></i> Medium risk</span>
                <span><i class="fa fa-circle" style="color: var(--hazard-yellow);" aria-hidden="true"></i> Low risk</span>
                <span><i class="fa fa-circle" style="color: var(--hazard-gray);" aria-hidden="true"></i> Pending verification</span>
            </div>
            <p class="field-hint"><i class="fa fa-shield-halved" aria-hidden="true"></i> Public view. Private household information is protected by the existing map API.</p>
            <details style="margin-top: 16px;">
                <summary style="cursor: pointer; font-size: .85rem; color: var(--primary);">View the existing hazard-map reference image</summary>
                <a href="assets/images/hinaplanon_hazard_map.jpg" target="_blank" rel="noopener"><img src="assets/images/hinaplanon_hazard_map.jpg" alt="Scanned Hinaplanon hazard map reference; open the full image for details" loading="lazy" style="width: 100%; height: auto; margin-top: 12px; border-radius: 8px;"></a>
            </details>
        </div>
    </section>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    if (typeof window.initHazardMap === 'function') window.initHazardMap('loginPublicMap', { zoom: 14 });
});
</script>
